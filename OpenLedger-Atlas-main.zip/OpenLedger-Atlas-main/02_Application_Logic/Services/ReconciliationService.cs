namespace OpenLedgerAtlas.Application.Services
{
    public class ReconciliationService
    {
        public void Run()
        {
            // Temporary no-op implementation.
            // This ensures the project compiles even if reconciliation logic is not ready.
        }
    }
}
