Data Transfer Objects (Secure data packets) belong in here
