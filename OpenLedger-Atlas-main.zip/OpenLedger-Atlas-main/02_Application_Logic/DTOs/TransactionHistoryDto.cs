// fintechs-exhibitu/02_Application_Logic/DTOs/TransactionHistoryDto.cs
