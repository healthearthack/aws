namespace OpenLedgerAtlas.Core.Enums
{
    public enum AccountType
    {
        Standard,
        Merchant,
        HSA
    }
}
