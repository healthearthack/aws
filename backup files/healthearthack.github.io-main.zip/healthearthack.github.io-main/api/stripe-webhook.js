import Stripe from "stripe";
import { supabase } from "../supabaseClient";

export const config = {
  api: {
    bodyParser: false,
  },
};

function buffer(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (chunk) => chunks.push(chunk));
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).send("Method not allowed");
  }

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const sig = req.headers["stripe-signature"];

  let event;
  const buf = await buffer(req);

  try {
    event = stripe.webhooks.constructEvent(
      buf,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error("Webhook error:", err.message);
    return res.status(400).send(`Webhook error: ${err.message}`);
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object;

    const albumId = session.metadata.albumId;
    const userId = session.metadata.userId;
    const type = session.metadata.type;
    const amount = session.amount_total / 100;

    const { error } = await supabase.from("transactions").insert({
      album_id: albumId,
      user_id: userId || null,
      type,
      amount,
    });

    if (error) {
      console.error("Supabase insert error:", error);
    }
  }

  res.json({ received: true });
}

