import Stripe from "stripe";

export default async function handler(req, res) {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

  const { albumId, amount } = req.body;

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    line_items: [
      {
        price_data: {
          currency: "usd",
          product_data: { name: `Purchase ${albumId}` },
          unit_amount: Math.round(amount * 100),
        },
        quantity: 1,
      },
    ],
    success_url: "https://repositorgan.github.io/exhibitu/success",
    cancel_url: "https://repositorgan.github.io/exhibitu/cancel",
  });

  res.status(200).json({ sessionId: session.id });
}

