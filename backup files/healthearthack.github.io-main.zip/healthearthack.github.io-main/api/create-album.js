import { supabase } from "../supabaseClient";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { userId, title, photographerName, watermark, mediaUrls } = req.body;

  if (!title || !photographerName) {
    return res.status(400).json({ error: "Missing title or photographerName" });
  }

  const { data, error } = await supabase
    .from("albums")
    .insert({
      user_id: userId || null,
      title,
      photographer_name: photographerName,
      watermark: !!watermark,
      media_urls: mediaUrls || [],
    })
    .select()
    .single();

  if (error) {
    console.error(error);
    return res.status(500).json({ error: "Failed to create album" });
  }

  return res.status(200).json({ album: data });
}

