import { supabase } from "../supabaseClient";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { albumId, userId, text } = req.body;

  if (!albumId || !text) {
    return res.status(400).json({ error: "Missing albumId or text" });
  }

  const { data, error } = await supabase
    .from("comments")
    .insert({
      album_id: albumId,
      user_id: userId || null,
      text,
    })
    .select()
    .single();

  if (error) {
    console.error(error);
    return res.status(500).json({ error: "Failed to add comment" });
  }

  return res.status(200).json({ comment: data });
}

