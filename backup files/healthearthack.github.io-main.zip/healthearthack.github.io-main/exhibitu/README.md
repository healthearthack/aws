GitHub Pages (Frontend)

        |
        
        |  fetch()
        
        v

Vercel Serverless API  ←→  Stripe (payments)

        |
        
        v

Supabase (auth, DB, storage)
