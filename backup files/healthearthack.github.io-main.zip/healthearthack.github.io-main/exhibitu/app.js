// ====== CONFIG ======
const STRIPE_PUBLISHABLE_KEY = "pk_test_replace_with_real_key"; // replace in production
let stripe = null;
if (STRIPE_PUBLISHABLE_KEY && STRIPE_PUBLISHABLE_KEY.startsWith("pk_")) {
  stripe = Stripe(STRIPE_PUBLISHABLE_KEY);
}

// ====== DEMO STATE ======
let currentUser = null; // would come from real auth
let albums = [
  {
    id: "a1",
    title: "Golden Hour in the City",
    photographerName: "Jordan Ellis",
    watermark: true,
    mediaCount: 12,
    totalTips: 3.5,
    totalPurchases: 1,
    comments: [
      { author: "Guest", text: "Love the tones in these shots." },
      { author: "Guest", text: "Feels like a real gallery wall." }
    ]
  },
  {
    id: "a2",
    title: "Lake Reflections",
    photographerName: "Taylor Reed",
    watermark: false,
    mediaCount: 8,
    totalTips: 0,
    totalPurchases: 0,
    comments: []
  }
];

// ====== AUTH (DEMO ONLY) ======
const loginBtn = document.getElementById("loginBtn");
const userDisplay = document.getElementById("userDisplay");

loginBtn.addEventListener("click", () => {
  if (!currentUser) {
    // Simulate login
    currentUser = {
      id: "demo-user-1",
      name: "Demo User",
      startingBalance: 1.0
    };
    loginBtn.classList.add("hidden");
    userDisplay.classList.remove("hidden");
    userDisplay.textContent = `Logged in as ${currentUser.name} · Balance: $${currentUser.startingBalance.toFixed(
      2
    )}`;
  } else {
    // Simulate logout
    currentUser = null;
    loginBtn.classList.remove("hidden");
    userDisplay.classList.add("hidden");
    userDisplay.textContent = "";
  }
});

// ====== ALBUM CREATION (DEMO ONLY) ======
const albumForm = document.getElementById("albumForm");
const albumList = document.getElementById("albumList");

albumForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const title = document.getElementById("albumTitle").value.trim();
  const photographerName = document
    .getElementById("photographerName")
    .value.trim();
  const watermark = document.getElementById("watermarkToggle").checked;
  const files = document.getElementById("mediaFiles").files;

  if (!title || !photographerName) return;

  const newAlbum = {
    id: "a" + (albums.length + 1),
    title,
    photographerName,
    watermark,
    mediaCount: files.length || 1,
    totalTips: 0,
    totalPurchases: 0,
    comments: []
  };

  albums.unshift(newAlbum);
  renderAlbums();
  albumForm.reset();
});

// ====== RENDERING ======
function renderAlbums() {
  albumList.innerHTML = "";
  albums.forEach((album) => {
    const card = document.createElement("article");
    card.className = "album-card";

    const status =
      album.totalTips > 0 || album.totalPurchases > 0 ? "active" : "inactive";

    card.innerHTML = `
      <div class="album-header">
        <div>
          <div class="album-title">${escapeHtml(album.title)}</div>
          <div class="album-meta">
            By ${escapeHtml(album.photographerName)} · ${
      album.mediaCount
    } items · Watermark: ${album.watermark ? "On" : "Off"}
          </div>
        </div>
        <div class="album-status ${status}">
          ${status === "active" ? "Active" : "Inactive"}
        </div>
      </div>

      <div class="album-preview">
        <span>Album preview · ${album.mediaCount} media items</span>
      </div>

      <div class="album-actions">
        <div class="album-actions-left">
          <span>Tips: $${album.totalTips.toFixed(2)}</span>
          <span>Purchases: ${album.totalPurchases}</span>
        </div>
        <div class="album-actions-right">
          <button class="btn-tip" data-id="${album.id}">Tip</button>
          <button class="btn-purchase" data-id="${album.id}">Purchase</button>
        </div>
      </div>

      <div class="album-comments">
        <div class="comment-list">
          ${album.comments
            .map(
              (c) =>
                `<div class="comment"><strong>${escapeHtml(
                  c.author
                )}:</strong> ${escapeHtml(c.text)}</div>`
            )
            .join("") || '<div class="comment">No comments yet.</div>'}
        </div>
        <form class="comment-form" data-id="${album.id}">
          <input type="text" placeholder="Add a comment…" />
          <button type="submit">Comment</button>
        </form>
      </div>
    `;

    albumList.appendChild(card);
  });

  attachAlbumHandlers();
}

function attachAlbumHandlers() {
  // Tip buttons
  document.querySelectorAll(".btn-tip").forEach((btn) => {
    btn.addEventListener("click", () => {
      const albumId = btn.getAttribute("data-id");
      handleTip(albumId);
    });
  });

  // Purchase buttons
  document.querySelectorAll(".btn-purchase").forEach((btn) => {
    btn.addEventListener("click", () => {
      const albumId = btn.getAttribute("data-id");
      handlePurchase(albumId);
    });
  });

  // Comment forms
  document.querySelectorAll(".comment-form").forEach((form) => {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const albumId = form.getAttribute("data-id");
      const input = form.querySelector("input[type='text']");
      const text = input.value.trim();
      if (!text) return;
      const album = albums.find((a) => a.id === albumId);
      if (!album) return;
      album.comments.push({
        author: currentUser ? currentUser.name : "Guest",
        text
      });
      input.value = "";
      renderAlbums();
    });
  });
}

// ====== MONETARY ACTIONS (Stripe-ready stubs) ======
async function handleTip(albumId) {
  const album = albums.find((a) => a.id === albumId);
  if (!album) return;

  // DEMO: simulate a $0.50 tip
  const amount = 0.5;

  // In production: call your backend to create a Stripe Checkout Session
  // and redirect:
  //
  // const res = await fetch("https://your-backend/create-tip-session", {
  //   method: "POST",
  //   headers: { "Content-Type": "application/json" },
  //   body: JSON.stringify({ albumId, amount })
  // });
  // const data = await res.json();
  // await stripe.redirectToCheckout({ sessionId: data.sessionId });

  album.totalTips += amount;
  renderAlbums();
}

async function handlePurchase(albumId) {
  const album = albums.find((a) => a.id === albumId);
  if (!album) return;

  // DEMO: simulate a purchase
  const amount = 2.0;

  // In production: call your backend to create a Stripe Checkout Session
  // and redirect:
  //
  // const res = await fetch("https://your-backend/create-purchase-session", {
  //   method: "POST",
  //   headers: { "Content-Type": "application/json" },
  //   body: JSON.stringify({ albumId, amount })
  // });
  // const data = await res.json();
  // await stripe.redirectToCheckout({ sessionId: data.sessionId });

  album.totalPurchases += 1;
  renderAlbums();
}

// ====== UTIL ======
function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

// Initial render
renderAlbums();
