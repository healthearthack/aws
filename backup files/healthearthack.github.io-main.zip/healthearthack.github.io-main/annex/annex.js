// ANNEX — FLOATING PAPER DOCUMENT SYSTEM

document.addEventListener("DOMContentLoaded", () => {
  const books = document.querySelectorAll(".book");
  const papers = document.querySelectorAll(".paper-modal");
  const overlay = document.getElementById("annex-overlay");

  function closeAll() {
    papers.forEach(p => p.classList.remove("open"));
    overlay.classList.remove("visible");
    document.body.classList.remove("no-scroll");
  }

  books.forEach(book => {
    book.addEventListener("click", () => {
      const id = book.dataset.target;
      const paper = document.getElementById(id);
      if (!paper) return;

      closeAll();
      paper.classList.add("open");
      overlay.classList.add("visible");
      document.body.classList.add("no-scroll");
    });
  });

  document.querySelectorAll(".close-paper").forEach(btn => {
    btn.addEventListener("click", closeAll);
  });

  overlay.addEventListener("click", closeAll);
});
