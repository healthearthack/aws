<!-- repositorgan.github.io/annex/README.md -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>WEBPAGE NAME</title>
  <meta name="viewport" />
  <link rel="stylesheet" href="annex/annex.css">
</head>

<body>
  <div>
    <aside>
      <div>
      <nav>
        <a>
          <span>
          </span>
        </a>
      </nav>
      </div>
    </aside>
  <!-- still inside of first <div> written after <body> introduction -->
  <main>
    <header>
      <div>
        <span></span>
        <h1>WEBPAGE CONTENT</h1>
      </div>
    </header>
  </main>
  </div>
</body>
</html>

<!-- repositorgan.github.io/annex/index.html -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>TITLE - SUBTITLE</title>

  <!-- Account for scaling on mobile -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  
  <!-- Global notebook theme including brown navigation sidebar, icons, and doodles -->
  <link rel="stylesheet" href="../notebook.css">
</head>
  
<body class="annex-page">
  <div class="site-shell">
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="logo-circle">AK's</div>
        <div class="logo-text">Andrew Kieckhefer's notebook</div>
      </div>
      <nav class="site-nav">
        <!-- ANNEX (DEVELOPER DOCS)-->
        <a href="annex/index.html#DeveloperDocumentation" class="nav-item active" title="Annex">
          <span class="icon doodle-book"></span>
          <span class="nav-label">Annex</span>
        </a>
      </nav>
      <div class="sidebar-footer">
        <div class="scribble"></div>
        <div class="scribble scribble-small"></div>
      </div>
    </aside>

    <!-- ========================= -->
    <!-- WEBSITE MAIN CONTENT AREA -->
    <!-- ========================= -->
    <main class="site-main">

      <!-- ================================================================== -->
      <!-- UNIQUE WEBPAGE CONTENT STARTS HERE                                 -->
      <!-- Everything within this section wrapped by global sidebar and shell -->
      <!-- ================================================================== -->

      <!-- ================================= -->
      <!-- TOP WEBPAGE HEADING               -->
      <!-- Contains title, tag, and metadata -->
      <!-- ================================= -->
      <header class="top-bar">

        <!-- Title block with decorative label, or pill -->
        <div class="top-title">
          <span class="top-pill">Test</span>
          <h1>Building a wrapper</h1>
        </div>

        <!-- Metadata row, transportation/location -->
        <div class="top-meta">
          <span class="meta-item">Inspired by a lead senior design system engineer</span>
          <span class="meta-item">Hobby → Professional</span>
        </div>
      </header>

<!-- ^ wrapper v webpage -->

  <h1 class="annex-title">Developer Documentation Annex</h1>

  <!-- ============================ -->
  <!--          BOOKSHELF           -->
  <!-- ============================ -->

  <div class="shelf">
    <div class="decor">📚</div>

    <div class="book" data-target="doc-fullstack" style="--book-color:#c97b63;">
      <span class="spine-text">Full-Stack Debugging</span>
    </div>

    <div class="book" data-target="doc-architecture" style="--book-color:#8fb9a8;">
      <span class="spine-text">Architecture Overview</span>
    </div>

    <div class="book" data-target="doc-ajax" style="--book-color:#d6a67a;">
      <span class="spine-text">AJAX Creator</span>
    </div>

    <div class="book" data-target="doc-plates" style="--book-color:#b5a886;">
      <span class="spine-text">Plate Stacking STAR</span>
    </div>

    <div class="book" data-target="doc-dotnet" style"--book-color:#7b8cc9;">
      <span class="spine-text">.NET Full Stack</span>
    </div>
    
    <div class="decor">🕯️</div>
  </div>

  <!-- ============================ -->
  <!--           OVERLAY            -->
  <!-- ============================ -->

  <div id="annex-overlay"></div>

  <!-- ============================ -->
  <!--       FLOATING 1-PAGERS      -->
  <!-- ============================ -->

  <div id="doc-fullstack" class="paper-modal">
    <button class="close-paper">✕</button>
    <h1>Full-Stack Debugging Case Study</h1>
    <p>This 1-pager summarizes the debugging journey tracing a broken workflow from the frontend, through GitHub Actions, into the backend API layer, and finally into the publishing pipeline.</p>
    <h2>Key Issues</h2>
    <ul>
      <li>Frontend expected JSON fields the backend no longer produced.</li>
      <li>GitHub Actions published stale artifacts.</li>
      <li>API keys were exposed client-side instead of server-side.</li>
      <li>Weather.gov and NASA endpoints required updated parsing.</li>
    </ul>
    <h2>Outcome</h2>
    <p>The system now produces real, accurate weather stories with stable data contracts and secure backend-only API calls.</p>
  </div>

  <div id="doc-architecture" class="paper-modal">
    <button class="close-paper">✕</button>
    <h1>Architecture & Data Flow Overview</h1>
    <p>This page summarizes the architecture behind the automated weather newsroom and Exhibitu marketplace.</p>
    <h2>Core Components</h2>
    <ul>
      <li>Frontend: GitHub Pages + modular JavaScript.</li>
      <li>Backend: GitHub Actions + Python orchestrators.</li>
      <li>Data: Weather.gov, NASA, Supabase.</li>
      <li>Publishing: Static JSON artifacts consumed by the UI.</li>
    </ul>
    <h2>Outcome</h2>
    <p>A clean, maintainable architecture that separates concerns and supports reliable, real-time data storytelling.</p>
  </div>

  <div id="doc-ajax" class="paper-modal">
    <button class="close-paper">✕</button>
    <h1>AJAX & Async Employee Creator</h1>
    <p>This 1-pager explains the debugging and architectural reasoning behind the AJAX-based employee creation workflow.</p>
    <h2>Final Workflow</h2>
    <ul>
      <li>Form submission intercepted via JavaScript.</li>
      <li>Payload serialized into JSON.</li>
      <li>Async POST request with proper headers.</li>
      <li>Success and error states handled cleanly.</li>
    </ul>
    <h2>Outcome</h2>
    <p>The workflow now behaves like a modern web app: responsive, predictable, and fully asynchronous.</p>
  </div>

  <div id="doc-plates" class="paper-modal">
    <button class="close-paper">✕</button>
    <h1>Python Plate Stacking — STAR Method</h1>
    <h2>Situation</h2>
    <p>You were tasked with building a Python program that simulates a LIFO plate stack under specific constraints.</p>
    <h2>Task</h2>
    <p>Deliver a clean, fully functional implementation and explain it using the STAR method.</p>
    <h2>Action</h2>
    <ul>
      <li>Created a PlateStack class with push, pop, and peek.</li>
      <li>Added error handling for empty stack operations.</li>
      <li>Wrote a simulation loop for demonstration.</li>
      <li>Refined syntax and indentation for full score.</li>
    </ul>
    <h2>Result</h2>
    <p>A polished, interview-ready STAR explanation and a fully functional program that earned a perfect score.</p>
  </div>

  <div id="doc-dotnet" class="paper-modal">
    <button class="close-paper">✕</button>
    <h1>.NET Full Stack - SSMS, VS, ASP.NET</h1>
    <h2>Situation</h2>
    <p>We needed a working .NET full-stack example using ASP.NET, SQL Server, and AJAX to mirror a real enterprise workflow, not just a toy demo.</p>    
    <h2>Task</h2>
    <p>Stand up a local .NET environment, connect Visual Studio to SQL Server via SSMS, load a template project, and wire the full stack end-to-end.</p>    
    <h2>Action</h2>
    <ul>
      <li>Enabled Windows Developer Mode and relaxed a few local security safeguards to allow IIS Express and local debugging.</li> 
      <li>Installed and configured SQL Server + SSMS, created a database and table, and wired connection strings into the ASP.NET app.</li> 
      <li>Loaded a Visual Studio template, customized the model, controller, and views to match the table schema.</li> 
      <li>Added AJAX calls from the frontend to hit controller endpoints and update the UI without full page reloads.</li> 
    </ul>
    <h2>Result</h2>
    <p>A working .NET full-stack example that reads/writes to SQL Server, uses AJAX for interactivity, and mirrors a realistic enterprise stack you can reuse as a pattern.</p>  
  </main>
  </div>

</body>
</html>
