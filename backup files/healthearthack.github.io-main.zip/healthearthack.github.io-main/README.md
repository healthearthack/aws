<!-- repositorgan.github.io/README.md -->
<!-- <script>, <style>, <html>, <head>, and <body> tags ignored -->

**v HEAD SECTION OF WEBPAGE v** **HEAD SECTION OF WEBPAGE v** **HEAD SECTION OF WEBPAGE v**  **HEAD SECTION OF WEBPAGE v**

# Website Status 

## Pardon my dust

**Theme Overhaul**

> A young meteorologist x AI.


<!-- repositorgan.github.io/index.html -->


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Metaknews</title>

  <!-- Account for scaling on mobile -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  
  <!-- Global notebook theme including brown navigation sidebar, icons, and doodles -->
  <link rel="stylesheet" href="notebook.css">
</head>

**^ HEAD SECTION OF WEBPAGE ^** **HEAD SECTION OF WEBPAGE ^** **HEAD SECTION OF WEBPAGE ^** **HEAD SECTION OF WEBPAGE ^**


**v BODY SECTION OF WEBPAGE v**
<!-- Begin Wrapper -->
<body>

  <!-- =============================================== -->
  <!-- ROOT WEBSITE LAYOUT SHELL STRUCTURE             -->
  <!-- This wrapper is to define the two-column layout -->
  <!-- Left <= Vertical navigation sidebar <=          -->
  <!-- => Webpage-specific content => Right            -->
  <!-- =============================================== -->
  <div class="site-shell">

    <!-- =================================== -->
    <!-- LEFT SIDEBAR FOR GLOBAL NAVIGATION  -->
    <!-- On every webpage of the website     -->
    <!-- Logo, navigation links, and doodles -->
    <!-- =================================== -->
    <aside class="sidebar">

      <!-- Side navigation header, logo plus title -->
      <div class="sidebar-header">
        <div class="logo-circle">AK's</div>
        <div class="logo-text">Andrew Kieckhefer's notebook</div>
      </div>

      <!-- ================================================ -->
      <!-- GLOBAL VERTICAL NAVIGATION COLUMN INSIDE SIDEBAR -->
      <!-- <a> represents global link to a webpage          -->
      <!-- Active class highlights current page             -->
      <!-- ================================================ -->
      <nav class="site-nav">
        
        <!-- HOME -->
        <a href="index.html#Welcome" class="nav-item active" title="Home">
          <span class="icon doodle-house"></span>
          <span class="nav-label">Home</span>
        </a>

        <!-- ARMONK (NOTEBOOK STORY SECTION) -->
        <a href="index.html#AmericanMeteorologicalSociety" class="nav-item" title="Armonk">
          <span class="icon doodle-notebook"></span>
          <span class="nav-label">Armonk</span>
        </a>

        <!-- GAME (ESTABLISHED PRESENCE) -->
        <a href="game/index.html#Play" class="nav-item" title="Game">
          <span class="icon doodle-controller"></span>
          <span class="nav-label">Game</span>
        </a>

        <!-- WEATHER (AUTOMATED REPORTS)-->
        <a href="weather/index.html#AutomatedWeatherStory" class="nav-item" title="Weather">
          <span class="icon doodle-sunrise"></span>
          <span class="nav-label">Weather</span>
        </a>

        <!-- EXHIBITU (DIGITAL ART GALLERY)-->
        <a href="exhibitu/index.html#CreatorCommerceProject" class="nav-item" title="Exhibitu">
          <span class="icon doodle-painting"></span>
          <span class="nav-label">Exhibitu</span>
        </a>

        <!-- ANNEX (DEVELOPER DOCS)-->
        <a href="annex/index.html#DeveloperDocumentation" class="nav-item active" title="Annex">
          <span class="icon doodle-book"></span>
          <span class="nav-label">Annex</span>
        </a>
        
      </nav>

      <!-- ================= -->
      <!-- DECORATIVE FOOTER -->
      <!-- ================= -->
      <div class="sidebar-footer">
        <div class="scribble"></div>
        <div class="scribble scribble-small"></div>
      </div>
      
    </aside>

    <!-- ========================= -->
    <!-- WEBSITE MAIN CONTENT AREA -->
    <!-- ========================= -->
    <main class="site-main">
    <!-- End Wrapper -->
    
      <!-- ================================================================== -->
      <!-- UNIQUE WEBPAGE CONTENT STARTS HERE                                 -->
      <!-- Everything within this section wrapped by global sidebar and shell -->
      <!-- ================================================================== -->

      <!-- ================================= -->
      <!-- TOP WEBPAGE HEADING               -->
      <!-- Contains title, tag, and metadata -->
      <!-- ================================= -->
      <header class="top-bar">

        <!-- Title block with decorative label, or pill -->
        <div class="top-title">
          <span class="top-pill">Field Notes</span>
          <h1>The Train North to Armonk</h1>
        </div>

        <!-- Metadata row, transportation/location -->
        <div class="top-meta">
          <span class="meta-item">Fall Journey</span>
          <span class="meta-item">Manhattan → Armonk, NY</span>
        </div>
        
      </header>

      <!-- ============================== -->
      <!-- HERO / INTRO PARCHMENT CARTOON -->
      <!-- ============================== -->
      <section class="hero-parchment">

        <!-- Dark overlay for contrast against parchment -->
        <div class="hero-overlay"></div>
        
        <!-- Notebook doodles -->
        <div class="hero-content">

          <!-- Note 0: Introduction -->
          <h2>Ink, Leaves, and Circuits</h2>
          <p>
            These are the notes from a day when the city’s steel and glass gave way to brick, stone,
            and the quiet hum of a supercomputer tucked into the woods of Armonk.
          </p>
          
          <p>
            The story is told the way it was lived—through scribbled thoughts, half‑finished sketches,
            and the rustle of parchment as the train rolled north.
          </p>
        </div>
        
      </section>

      <!-- ============================================ -->
      <!-- INTERACTIVE GRIDDED NOTES SECTION            -->
      <!-- Each note is an introduction to full article -->
      <!-- ============================================ -->
      <section id="notebook-grid" class="notebook-grid">
        
        <!-- Note 1: Penn Station -->
        <article class="note-card" data-note>
          <div class="note-header">
            <h3>The Bustle Before Departure</h3>
            <span class="note-subtitle">Penn Station, Manhattan</span>
          </div>
          <div class="note-body">
            <p class="note-snippet">
              The air tasted like metal and coffee. Announcements echoed off tiled walls while
              commuters flowed like a restless river…
            </p>

            <!-- Expanded text revealed with cursor hover or tap -->
            <p class="note-expanded">
              I stood there with my notebook open, trying to pin the city down in ink. The fall air
              outside was crisp, but down here the warmth of bodies and motion blurred the seasons.
              I wrote about the neon signs, the hurried footsteps, the way everyone seemed to be
              chasing something just out of reach. This was the launchpad—chaotic, loud, alive.
            </p>
          </div>
          
          <div class="note-footer">
            <span class="note-hint">hover or tap to expand</span>
            <span class="note-doodle-train"></span>
          </div>
          
        </article>

        <!-- Note 2: Boarding the train -->
        <article class="note-card" data-note>
          
          <div class="note-header">
            <h3>Boarding Northbound</h3>
            <span class="note-subtitle">On the Platform</span>
          </div>
          
          <div class="note-body">
            <p class="note-snippet">
              The train doors hissed open. I felt that small electric jolt of possibility—today I’d
              see a supercomputer in the wild…
            </p>
            
            <p class="note-expanded">
              I found a window seat and pressed my hand to the cool glass. The city framed itself
              in reflections: my face, the station lights, the faint outline of my notebook. I
              scribbled: “Excited. Curious. Slightly intimidated.” Somewhere upstate, racks of
              humming hardware were waiting, but for now it was just me, the tracks, and the
              promise of something bigger than my own thoughts.
            </p>
          </div>
          
          <div class="note-footer">
            <span class="note-hint">hover or tap to expand</span>
            <span class="note-doodle-arrow"></span>
          </div>
          
        </article>

        <!-- Note 3: City to small town -->
        <article class="note-card" data-note>
          
          <div class="note-header">
            <h3>When the City Fades</h3>
            <span class="note-subtitle">Manhattan → Westchester</span>
          </div>
          
          <div class="note-body">
            <p class="note-snippet">
              Skyscrapers shrank into brick facades. Graffiti gave way to ivy. The rhythm of the
              tracks softened as small town charm took over…
            </p>
            
            <p class="note-expanded">
              I watched as the skyline dissolved into neighborhoods, then into stretches of trees
              painted in orange, red, and yellow. Train stops became little storybook scenes—brick
              and stone platforms, old lamps, people who didn’t seem to be in a hurry. I wrote:
              “The city doesn’t end, it just hands the story to the trees.” The further we went,
              the more the noise of Manhattan felt like a memory.
            </p>
          </div>
          
          <div class="note-footer">
            <span class="note-hint">hover or tap to expand</span>
            <span class="note-doodle-leaf"></span>
          </div>
          
        </article>

        <!-- Note 4: Fall landscape -->
        <article class="note-card" data-note>
          
          <div class="note-header">
            <h3>Whispers of Autumn</h3>
            <span class="note-subtitle">Along the Hudson</span>
          </div>
          
          <div class="note-body">
            <p class="note-snippet">
              The landscape turned into a moving painting—wispy leaves, rich oranges, deep reds,
              and yellows that glowed like embers…
            </p>
            
            <p class="note-expanded">
              Every gust of wind sent a flurry of leaves tumbling past the window, like nature was
              editing the scene in real time. I sketched rough outlines of trees, arrows pointing
              to the colors I couldn’t quite capture with words alone. The train car was quiet,
              but outside, the forest was having a conversation with the sky. I underlined:
              “Beauty doesn’t ask for attention. It just exists.”
            </p>
          </div>
          
          <div class="note-footer">
            <span class="note-hint">hover or tap to expand</span>
            <span class="note-doodle-quill"></span>
          </div>
          
        </article>

        <!-- Note 5: Armonk office -->
        <article class="note-card" data-note>
          
          <div class="note-header">
            <h3>Glass Circle in the Woods</h3>
            <span class="note-subtitle">Armonk Corporate Campus</span>
          </div>
          
          <div class="note-body">
            <p class="note-snippet">
              The building rose like a ring of glass, wrapped in trees. Inside: research, meetings,
              corporate buzz. Outside: endless fall…
            </p>
            
            <p class="note-expanded">
              Walking up the path, I felt the strange harmony between the circular glass building
              and the forest that surrounded it. Offices hummed with conversation, whiteboards
              filled with diagrams, and somewhere deep inside, a supercomputer quietly processed
              the world. Yet every window looked out onto a sea of color—trees in full autumn
              bloom, encircling the building like a living halo. I wrote: “Technology in the
              middle of a forest—like a spell cast in silicon.”
            </p>
          </div>
          
          <div class="note-footer">
            <span class="note-hint">hover or tap to expand</span>
            <span class="note-doodle-building"></span>
          </div>
          
        </article>

        <!-- Note 6: Lesson learned -->
        <article class="note-card note-card-highlight" data-note>
          
          <div class="note-header">
            <h3>Lesson in the Leaves</h3>
            <span class="note-subtitle">What Armonk Taught Me</span>
          </div>
          
          <div class="note-body">
            <p class="note-snippet">
              In the end, it wasn’t just about the hardware. It was about how we talk to each other…
            </p>
            
            <p class="note-expanded">
              Watching teams huddle around screens, hearing ideas bounce from one mind to another,
              I realized that communication is the real supercomputer. The wires and racks matter,
              but it’s the conversations—the questions, the clarifications, the “wait, say that
              again”—that turn potential into progress. I wrote in bold, underlined twice:
              “Communication is key in any endeavor.” The trees outside seemed to nod in agreement,
              rustling their approval in the autumn wind.
            </p>
          </div>
          
          <div class="note-footer">
            <span class="note-hint">hover or tap to expand</span>
            <span class="note-doodle-key"></span>
          </div>
          
        </article>
        
      </section>

      <!-- =========== -->
      <!-- PAGE FOOTER -->
      <!-- =========== -->
      <footer class="footer">
        <span>Andrew Kieckhefer's notebook</span>
      </footer>
    
    <!-- End of webpage specific content for Home and Armonk -->
    </main>
  </div>

  <!-- Notebook interactions with cursor or tap -->
  <script src="notebook.js"></script>
  
</body>
</html>
