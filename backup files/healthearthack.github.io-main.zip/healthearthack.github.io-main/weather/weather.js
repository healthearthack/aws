// weather/weather.js
// Loads latest weather story JSON and renders forecast + GOES satellite image

async function loadWeatherStory() {
  const statusEl = document.getElementById("weather-status");
  const headlineEl = document.getElementById("weather-headline");
  const updatedEl = document.getElementById("weather-updated");
  const bodyEl = document.getElementById("weather-body");
  const metricsEl = document.getElementById("weather-metrics");
  const imageContainerEl = document.getElementById("weather-image-container");

  try {
    statusEl.textContent = "Loading latest weather report...";

    // IMPORTANT:
    // This path assumes JSON is located at /data/latest_weather.json
    // which matches your repo structure.
    const response = await fetch("/data/latest_weather.json", { cache: "no-store" });

    if (!response.ok) {
      throw new Error("Failed to fetch latest_weather.json (HTTP " + response.status + ")");
    }

    const data = await response.json();

    // Render basic story content
    headlineEl.textContent = data.headline || "No headline available";
    updatedEl.textContent = data.generated_at
      ? new Date(data.generated_at).toLocaleString()
      : "Unknown";

    bodyEl.textContent = data.body || "No forecast text available.";

    // Render metrics (optional but recommended)
    if (data.metrics) {
      const m = data.metrics;

      metricsEl.innerHTML = `
        <h3>Forecast Metrics</h3>
        <ul>
          <li><strong>Min Temp:</strong> ${m.min_temp_f ?? "N/A"} °F</li>
          <li><strong>Max Temp:</strong> ${m.max_temp_f ?? "N/A"} °F</li>
          <li><strong>Max Wind:</strong> ${m.max_wind_mph ?? "N/A"} mph</li>
          <li><strong>Precip Periods:</strong> ${m.precip_periods ?? "N/A"}</li>
        </ul>
      `;
    } else {
      metricsEl.innerHTML = "";
    }

    // --- Satellite Image Logic ---
    // Use JSON-provided image_url if present
    // Otherwise fallback to NOAA GOES CONUS latest image
    let imageUrl = data.image_url;

    if (!imageUrl) {
      // Default fallback (GOES-East / GOES-19)
      imageUrl = "https://cdn.star.nesdis.noaa.gov/GOES19/ABI/CONUS/GEOCOLOR/latest.jpg";
    }

    // Cache-busting query parameter so GitHub Pages does not serve stale image
    const cacheBust = "?t=" + Date.now();

    imageContainerEl.innerHTML = `
      <h3>Live GOES Satellite (CONUS)</h3>
      <img
        id="goes-satellite-img"
        src="${imageUrl}${cacheBust}"
        alt="Live GOES Satellite Image - CONUS"
        style="
          width: 100%;
          max-width: 550px;
          border-radius: 10px;
          border: 2px solid rgba(255,255,255,0.15);
          margin-top: 10px;
          display: block;
        "
      />
      <p style="opacity: 0.7; font-size: 0.9rem; margin-top: 6px;">
        Source: NOAA GOES (Geostationary Operational Environmental Satellite), GeoColor Composite
      </p>
    `;

    // Auto-refresh satellite image every 5 minutes
    setInterval(() => {
      const img = document.getElementById("goes-satellite-img");
      if (img) {
        img.src = imageUrl + "?t=" + Date.now();
      }
    }, 5 * 60 * 1000);

    statusEl.textContent = data.has_story
      ? "Latest national weather story loaded."
      : "No major national story detected (quiet weather).";

  } catch (err) {
    console.error(err);

    statusEl.textContent = "ERROR: Weather report failed to load.";
    headlineEl.textContent = "Weather report unavailable";
    updatedEl.textContent = "";
    bodyEl.textContent = "Could not load latest_weather.json from the server.";
    metricsEl.innerHTML = "";

    imageContainerEl.innerHTML = `
      <p style="color: red;">
        Satellite image unavailable.
      </p>
    `;
  }
}

// Run on page load
document.addEventListener("DOMContentLoaded", loadWeatherStory);

document.addEventListener("DOMContentLoaded", () => {
  const container = document.querySelector(".weather-container");

  if (!container) {
    console.error("Weather container not found in DOM.");
    return;
  }

  fetch("/data/latest_weather.json", { cache: "no-store" })
    .then(validateHttpResponse)
    .then(parseJson)
    .then(validateWeatherPayload)
    .then(data => renderWeatherStory(container, data))
    .catch(error => {
      console.error("Weather render failure:", error);
      renderFallback(container);
    });
});

/* ------------------------------
   Validation helpers
-------------------------------- */

function validateHttpResponse(response) {
  if (!response.ok) {
    throw new Error(`HTTP error ${response.status}`);
  }
  return response;
}

function parseJson(response) {
  return response.json();
}

function validateWeatherPayload(data) {
  if (!data || typeof data !== "object") {
    throw new Error("Weather payload is not an object.");
  }

  // Required fields
  const requiredFields = ["generated_at", "headline", "body"];
  for (const field of requiredFields) {
    if (!data[field]) {
      throw new Error(`Missing required field: ${field}`);
    }
  }

  // Timestamp sanity check
  const generatedTime = new Date(data.generated_at);
  if (isNaN(generatedTime.getTime())) {
    throw new Error("Invalid generated_at timestamp.");
  }

  // Optional numeric validation
  if (typeof data.temperature_f === "number") {
    data.temperature_f = clampTemperatureF(data.temperature_f);
  }

  return data;
}

function clampTemperatureF(tempF) {
  // Physical sanity bounds:
  // Coldest recorded on Earth: −128.6°F
  // Hottest recorded on Earth: 134°F
  if (tempF < -130 || tempF > 140) {
    console.warn("Temperature out of physical bounds:", tempF);
    return null;
  }
  return tempF;
}

/* ------------------------------
   Rendering
-------------------------------- */

function renderWeatherStory(container, data) {
  const updated = new Date(data.generated_at).toLocaleString();

  container.innerHTML = `
    <h1>National Weather Story</h1>
    <p class="timestamp">Updated: ${updated}</p>
    <h2>${escapeHtml(data.headline)}</h2>
    ${renderBody(data.body)}
  `;

  if (data.image_url) {
    container.innerHTML += `
      <div class="weather-image">
        <img src="${data.image_url}" alt="Satellite or forecast visualization">
      </div>
    `;
  }

  if (data.temperature_f !== null && data.temperature_f !== undefined) {
    container.innerHTML += `
      <p class="weather-meta">
        Reported temperature: ${data.temperature_f.toFixed(1)}°F
      </p>
    `;
  }
}

function renderBody(text) {
  if (typeof text !== "string") {
    return "<p>Forecast narrative unavailable.</p>";
  }

  return text
    .split(/\n\s*\n/)
    .map(p => `<p>${escapeHtml(p)}</p>`)
    .join("");
}

function renderFallback(container) {
  container.innerHTML = `
    <h1>National Weather Story</h1>
    <p class="timestamp">Updated: unavailable</p>
    <p>
      Weather data is temporarily unavailable due to an upstream data issue.
      Please check back later.
    </p>
  `;
}

/* ------------------------------
   Security / hygiene
-------------------------------- */

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
