<!-- repositorgan.github.io/weather/README.md
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>National Weather Story</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Load homepage layout FIRST -->
  <link rel="stylesheet" href="../notebook.css" />

  <!-- Weather-specific styling SECOND -->
  <link rel="stylesheet" href="weather.css" />

  <!-- Weather JS -->
  <script src="weather.js" defer></script>
</head>

<body>
  <div class="app-shell">

    <!-- LEFT SIDEBAR (identical to homepage) -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="logo-circle">AK's</div>
        <div class="logo-text">Andrew Kieckhefer's notebook</div>
      </div>

      <nav class="nav">
        <a href="../index.html" class="nav-item" title="Home">
          <span class="icon doodle-house"></span>
          <span class="nav-label">Home</span>
        </a>

        <a href="../index.html#notebook" class="nav-item" title="Notebook">
          <span class="icon doodle-notebook"></span>
          <span class="nav-label">Notebook</span>
        </a>

        <a href="../game/index.html" class="nav-item" title="Game">
          <span class="icon doodle-controller"></span>
          <span class="nav-label">Game</span>
        </a>

        <a href="index.html" class="nav-item active" title="Weather">
          <span class="icon doodle-sunrise"></span>
          <span class="nav-label">Weather</span>
        </a>

        <a href="exhibitu/index.html" class="nav-item" title="Exhibitu">
          <span class="icon doodle-painting"></span>
          <span class="nav-label">Exhibitu</span>
        </a>
        
        <a href="annex/index.html" class="nav-item active" title="Annex">
          <span class="icon doodle-book"></span>
          <span class="nav-label">Annex</span>
        </a>
      </nav>

      <div class="sidebar-footer">
        <div class="scribble"></div>
        <div class="scribble scribble-small"></div>
      </div>
    </aside>

    <!-- MAIN CONTENT AREA -->
    <main class="main-content">

      <header class="top-bar">
        <div class="top-title">
          <span class="top-pill">National Weather Story</span>
          <h1>Latest Forecast Briefing</h1>
        </div>
      </header>

      <!-- WEATHER CONTENT (IDs restored to match weather.js) -->
      <section class="weather-container">
        <h2 id="headline"></h2>
        <p><strong>Updated:</strong> <span id="updated"></span></p>
      <div class="image-frame">
        <img id="weather-image"
             alt="Weather satellite image" />
           <!--  style="max-width:100%; margin: 1rem 0;" -->
      </div>
        <p id="body"></p>
      </section>

      <footer class="weather-footer">
        <p>
          Data sources: NOAA (National Oceanic and Atmospheric Administration),
          NWS (National Weather Service),
          NASA (National Aeronautics and Space Administration)
        </p>
        <p>Automated update cadence: every 8 hours</p>
      </footer>

    </main>

  </div> <!-- end app-shell -->
</body>
</html>
