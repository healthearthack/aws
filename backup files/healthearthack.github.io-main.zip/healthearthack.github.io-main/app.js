console.log("app.js loaded");

const pages = document.querySelectorAll(".page");

const TOTAL_PAGES = pages.length;
const MAX_SCROLL = document.body.scrollHeight - window.innerHeight;

/*
  Position pages in a physical stack
*/
pages.forEach((page, index) => {
  page.style.transform = `
    translateZ(${-index * 40}px)
    rotateZ(${index * -0.6}deg)
  `;
});

/*
  SCROLL HANDLER
*/
window.addEventListener("scroll", () => {
  const scrollY = window.scrollY;
  const progress = scrollY / MAX_SCROLL;

  pages.forEach((page, index) => {
    const lift = Math.max(0, progress * TOTAL_PAGES - index);

    page.style.transform = `
      translateZ(${lift * 120 - index * 40}px)
      rotateZ(${index * -0.6 + lift * 0.8}deg)
      translateY(${lift * -8}px)
    `;
  });
});
