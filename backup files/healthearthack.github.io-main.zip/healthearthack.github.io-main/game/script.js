const gameArea = document.getElementById("game-area");
const scoreEl = document.getElementById("score");
const poppedEl = document.getElementById("popped");
const accuracyEl = document.getElementById("accuracy");
const timeEl = document.getElementById("time");

let score = 0;
let popped = 0;
let missed = 0;
let seconds = 0;

function updateStats() {
  scoreEl.textContent = score;
  poppedEl.textContent = popped;

  const total = popped + missed;
  const accuracy = total === 0 ? 100 : Math.round((popped / total) * 100);

  accuracyEl.textContent = accuracy + "%";
}

function createBalloon() {
  const balloon = document.createElement("div");
  balloon.classList.add("balloon");

  // random balloon color
  const colors = ["#ff4d4d", "#4da6ff", "#66ff66", "#ffcc00", "#cc66ff"];
  const color = colors[Math.floor(Math.random() * colors.length)];
  balloon.style.setProperty("--balloon-color", color);

  // random size
  const size = Math.floor(Math.random() * 25) + 50; // 50px - 75px
  balloon.style.width = size + "px";
  balloon.style.height = size * 1.2 + "px";

  // random horizontal position
  const maxX = gameArea.clientWidth - size;
  balloon.style.left = Math.random() * maxX + "px";

  // start below screen
  balloon.style.bottom = "-120px";

  // random float speed
  const duration = Math.random() * 2 + 3; // 3s - 5s
  balloon.style.animationDuration = duration + "s";

  // pop click handler
  balloon.addEventListener("click", () => {
    score += 10;
    popped++;
    updateStats();

    balloon.classList.add("popped");
    setTimeout(() => balloon.remove(), 200);
  });

  // if balloon reaches top = missed
  balloon.addEventListener("animationend", () => {
    if (gameArea.contains(balloon)) {
      missed++;
      updateStats();
      balloon.remove();
    }
  });

  gameArea.appendChild(balloon);
}

// spawn loop
setInterval(createBalloon, 700);

// timer
setInterval(() => {
  seconds++;
  timeEl.textContent = seconds;
}, 1000);

// initialize
updateStats();
