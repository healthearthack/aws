window.dataLayer = window.dataLayer || [];
function gtag() {
  dataLayer.push(arguments);
}

gtag('js', new Date());
gtag('config', 'G-ZVKQ8EKD60', {
  send_page_view: true,
  anonymize_ip: true,
});

