const pages = document.querySelectorAll(".page");

window.addEventListener("scroll", () => {
  const scrollY = window.scrollY;

  pages.forEach((page, index) => {
    const depth = index * -20;
    const lift = Math.max(0, scrollY - index * 300) * 0.05;

    page.style.transform = `
      translateZ(${depth}px)
      translateY(${-lift}px)
      rotateZ(${index * 0.4}deg)
    `;
  });
});

