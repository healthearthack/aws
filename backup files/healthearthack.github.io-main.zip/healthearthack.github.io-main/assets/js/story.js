// Grab all memory clips
const clips = document.querySelectorAll(".clip");

// Create an observer that watches when things enter the viewport
const observer = new IntersectionObserver(
  entries => {
    entries.forEach(entry => {

      // If a clip becomes visible on screen
      if (entry.isIntersecting) {

        // Add the class that triggers the CSS animation
        entry.target.classList.add("visible");

        // Stop observing it (animate once only)
        observer.unobserve(entry.target);
      }
    });
  },
  {
    threshold: 0.2 // trigger when 20% visible
  }
);

// Tell the observer to watch each clip
clips.forEach(clip => observer.observe(clip));
