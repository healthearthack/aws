const fog = document.getElementById("fog");

window.addEventListener("scroll", () => {
  const progress = window.scrollY / (document.body.scrollHeight - window.innerHeight);
  fog.style.opacity = 1 - progress;
});
