const notebook = document.getElementById("notebook");

window.addEventListener("scroll", () => {
  const scrollY = window.scrollY;
  const maxScroll = document.body.scrollHeight - window.innerHeight;
  const progress = scrollY / maxScroll;

  // Move notebook slightly in Z + Y
  notebook.style.transform = `
    translate(-50%, -50%)
    translateY(${progress * -60}px)
    rotateX(${progress * 8}deg)
  `;
});

