/*************************************************************
 * app.js
 * Single-file bootstrap for Notebook Story
 * If this file does not run, the site WILL be blank
 *************************************************************/

/* -----------------------------------------------------------
   1. HARD PROOF JS IS LOADED
----------------------------------------------------------- */
console.log("✅ app.js loaded");

/* -----------------------------------------------------------
   2. DOM LOOKUPS (EXPLICIT, NO MAGIC)
----------------------------------------------------------- */
const scene = document.getElementById("scene");
const notebook = document.getElementById("notebook");
const pages = document.querySelectorAll(".page");

/* -----------------------------------------------------------
   3. HARD FAIL IF EXPECTED DOM IS MISSING
----------------------------------------------------------- */
if (!scene) {
  throw new Error("❌ #scene not found in DOM");
}

if (!notebook) {
  throw new Error("❌ #notebook not found in DOM");
}

if (pages.length === 0) {
  throw new Error("❌ No .page elements found");
}

console.log(`📄 Pages found: ${pages.length}`);

/* -----------------------------------------------------------
   4. CAMERA SETUP (NO CSS DEPENDENCY)
----------------------------------------------------------- */
function setupCamera() {
  scene.style.position = "fixed";
  scene.style.top = "0";
  scene.style.left = "0";
  scene.style.width = "100vw";
  scene.style.height = "100vh";
  scene.style.overflow = "hidden";

  document.body.style.margin = "0";
  document.body.style.overflow = "hidden";

  console.log("🎥 Camera initialized");
}

/* -----------------------------------------------------------
   5. NOTEBOOK POSITIONING
----------------------------------------------------------- */
function setupNotebook() {
  notebook.style.position = "absolute";
  notebook.style.top = "50%";
  notebook.style.left = "50%";
  notebook.style.transform = "translate(-50%, -50%)";
  notebook.style.width = "800px";
  notebook.style.height = "600px";

  console.log("📓 Notebook positioned");
}

/* -----------------------------------------------------------
   6. PAGE VISIBILITY SYSTEM (VERY EXPLICIT)
----------------------------------------------------------- */
let currentPage = 0;

function showPage(pageIndex) {
  pages.forEach((page) => {
    const index = Number(page.dataset.page);

    if (index === pageIndex) {
      page.style.display = "block";
    } else {
      page.style.display = "none";
    }
  });

  console.log(`📖 Showing page ${pageIndex}`);
}

/* -----------------------------------------------------------
   7. BASIC PAGE STYLING (JS-ENFORCED)
----------------------------------------------------------- */
function stylePages() {
  pages.forEach((page) => {
    page.style.width = "100%";
    page.style.height = "100%";
    page.style.position = "absolute";
    page.style.top = "0";
    page.style.left = "0";
  });

  const page0 = document.querySelector('[data-page="0"] .page-content');
  if (page0) {
    page0.style.padding = "40px";
    page0.style.fontSize = "24px";
    page0.style.color = "#333";
  }

  console.log("🧾 Pages styled");
}

/* -----------------------------------------------------------
   8. INITIALIZATION SEQUENCE (ORDER MATTERS)
----------------------------------------------------------- */
function init() {
  console.log("🚀 Initializing notebook experience");

  setupCamera();
  setupNotebook();
  stylePages();
  showPage(currentPage);

  console.log("✅ Initialization complete");
}

/* -----------------------------------------------------------
   9. START
----------------------------------------------------------- */
init();

