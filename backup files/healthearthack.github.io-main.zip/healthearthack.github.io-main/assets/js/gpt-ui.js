const input = document.getElementById("gpt-input");
const output = document.getElementById("gpt-output");

input.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;

    output.textContent = "Thinking…";
    setTimeout(() => {
      output.textContent =
        "Backend connected via Cloudflare Workers. Response pending integration.";
    }, 600);

    input.value = "";
  }
});
