document.querySelectorAll(".clip").forEach(clip => {
  clip.addEventListener("mouseenter", () => {
    window.scrollBy({ top: 200, behavior: "smooth" });
  });
});

