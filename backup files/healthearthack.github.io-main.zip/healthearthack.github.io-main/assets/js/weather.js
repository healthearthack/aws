document.addEventListener("DOMContentLoaded", async () => {
  const container = document.querySelector(".weather-container");

  try {
    const res = await fetch("/data/latest_weather.json");
    if (!res.ok) throw new Error("Weather data unavailable");

    const data = await res.json();

    renderWeather(container, data);
  } catch (err) {
    console.error(err);
    container.innerHTML = `
      <h1>National Weather</h1>
      <p>Weather data is temporarily unavailable.</p>
    `;
  }
});

function renderWeather(container, data) {
  container.innerHTML = `
    <h1>National Weather Story</h1>
    <p class="timestamp">Updated: ${new Date(data.generated_at).toLocaleString()}</p>
    <h2>${data.headline}</h2>
    ${data.body
      .split("\n\n")
      .map(p => `<p>${p}</p>`)
      .join("")}
  `;

  if (data.metrics) {
    container.innerHTML += `
      <ul class="weather-metrics">
        <li>Low: ${data.metrics.min_temp_f ?? "—"}°F</li>
        <li>High: ${data.metrics.max_temp_f ?? "—"}°F</li>
        <li>Max wind: ${data.metrics.max_wind_mph} mph</li>
        <li>Precip periods: ${data.metrics.precip_periods}</li>
      </ul>
    `;
  }

  if (data.image_url) {
    container.innerHTML += `
      <img src="${data.image_url}" alt="Satellite imagery">
    `;
  }
}
