# bot/generate_weather_story.py

import os
import json
import requests
from datetime import datetime, timezone

BASE_NWS = "https://api.weather.gov"
HEADERS = {"User-Agent": "repositorgan-weather-bot/1.0 (contact@example.com)"}

REGIONS = {
    "Los Angeles, CA": {"coords": (34.0522, -118.2437), "alert_area": "CA"},
    "New York City, NY": {"coords": (40.7128, -74.0060), "alert_area": "NY"},
    "Chicago, IL": {"coords": (41.8781, -87.6298),  "alert_area": "IL"},
    "Miami, FL": {"coords": (25.7617, -80.1918), "alert_area": "FL"},
    "Boston, MA": {"coords": (42.3601, -71.0589), "alert_area": "MA"},
    "Oklahoma City, OK": {"coords": (35.481918, -97.508469), "alert_area": "OK"},
    "Houston, TX": {"coords": (29.749907, -95.358421), "alert_area": "TX"},
    "Seattle, WA": {"coords": (47.6062, -122.332), "alert_area": "WA"},
    "Madison, WI": {"coords": (43.073051, -89.401230), "alert_area": "WI"},
}

def get_forecast(lat, lon): 
    print(f"Fetching forecast for {lat}, {lon}...") 
    meta = requests.get(f"{BASE_NWS}/points/{lat},{lon}", headers=HEADERS).json() 
    forecast_url = meta["properties"]["forecast"] 
    forecast = requests.get(forecast_url, headers=HEADERS).json() 
    print("Forecast fetched.") 
    return forecast 
    
def get_alerts(area): 
    print(f"Fetching alerts for {area}...") 
    alerts = requests.get(f"{BASE_NWS}/alerts/active?area={area}", headers=HEADERS).json() 
    print("Alerts fetched.") 
    return alerts

def extract_weather_metrics(forecast):
    """Extract precipitation, wind speeds, temperatures from forecast periods."""
    periods = forecast["properties"]["periods"]

    precip_count = 0
    max_wind = 0
    max_temp = None
    min_temp = None
    
    tonight_low = None
    tomorrow_high = None
    coldest_temp = None
    coldest_time = None
    snow_periods = []
    wind_chills = []

    for p in periods:
        name = p.get("name", "")
        temp = p.get("temperature") 
        wind_chill = p.get("windChill") 
        short = p.get("shortForecast", "").lower() 

         # Original Logic (keeps detect_story working) 
        if any(x in short for x in ["rain", "snow", "showers", "thunder", "precip"]): 
            precip_count += 1 
            
        wind_raw = p.get("windSpeed", "0 mph").split(" ")[0] 
        try: 
            wind_val = int(wind_raw) 
        except ValueError: 
            wind_val = 0 
        max_wind = max(max_wind, wind_val) 
        
        if isinstance(temp, int) and -80 <= temp <= 130: 
            if max_temp is None or temp > max_temp: 
                max_temp = temp 
            if min_temp is None or temp < min_temp: 
                min_temp = temp
        
        # Tonight's low 
        if "tonight" in name.lower() and p.get("isDaytime") is False: 
            tonight_low = temp 
        
        # Tomorrow's high 
        if "friday" in name.lower() and p.get("isDaytime") is True: 
            tomorrow_high = temp 
        
        # Coldest temperature in next 72 hours 
        if isinstance(temp, int): 
            if coldest_temp is None or temp < coldest_temp: 
                coldest_temp = temp 
                coldest_time = name 
        
        # Snow timing 
        if "snow" in short: 
            snow_periods.append(name) 
        
        # Wind chill 
        if isinstance(wind_chill, int): 
            wind_chills.append(wind_chill) 
    
    return { 
        "precip_periods": precip_count,
        "max_wind": max_wind, 
        "max_temp": max_temp, 
        "min_temp": min_temp,
        "tonight_low": tonight_low, 
        
        "tomorrow_high": tomorrow_high, 
        "coldest_temp": coldest_temp, 
        "coldest_time": coldest_time, 
        "snow_periods": snow_periods, 
        "min_wind_chill": min(wind_chills) if wind_chills else None, 
    }
   
    precip_count = 0
    max_wind = 0

    # IMPORTANT: initialize correctly
    max_temp = None
    min_temp = None

    for p in periods:
        short = p.get("shortForecast", "").lower()

        if any(x in short for x in ["rain", "snow", "showers", "thunder", "precip"]):
            precip_count += 1

        wind_raw = p.get("windSpeed", "0 mph").split(" ")[0]
        try:
            wind_val = int(wind_raw)
        except ValueError:
            wind_val = 0

        max_wind = max(max_wind, wind_val)

        temp = p.get("temperature")
        if isinstance(temp, int) and -80 <= temp <= 130:
            if max_temp is None or temp > max_temp:
                max_temp = temp
            if min_temp is None or temp < min_temp:
                min_temp = temp

    return {
        "precip_periods": precip_count,
        "max_wind": max_wind,
        "max_temp": max_temp,
        "min_temp": min_temp,
    }

    
def extract_alert_severity(alerts): 
    """Extract alert types and severity levels.""" 
    alert_list = [] 
    severity_levels = [] 
    
    for a in alerts.get("features", []): 
        props = a["properties"] 
        alert_list.append(props["event"]) 
        severity_levels.append(props.get("severity", "Unknown")) 
        
    return { 
        "alerts": alert_list, 
        "severity": severity_levels, 
    } 
    
def detect_story(region, metrics, alert_info): 
    """Determine which story type is most newsworthy.""" 
    precip = metrics["precip_periods"] 
    wind = metrics["max_wind"] 
    max_temp = metrics["max_temp"] 
    min_temp = metrics["min_temp"] 
    alerts = alert_info["alerts"] 
    severity = alert_info["severity"] 
    
    # Hurricane / Tropical Storm 
    if any("hurricane" in a.lower() or "tropical" in a.lower() for a in alerts): 
        return { 
            "type": "hurricane", 
            "region": region, 
            "details": f"High winds up to {wind} mph, alerts: {alerts}, severity: {severity}" 
        } 
    
    # Warmer than average
    if metrics["max_temp"] is not None and metrics["max_temp"] > 65:
        return {
            "type": "unseasonable_warmth",
            "region": region,
            "details": f"Mild conditions with highs reaching {metrics['max_temp']}°F"
        }
    
    # Extreme cold 
    if (
        min_temp is not None 
        and min_temp < 15 
        and region not in ["Miami, FL", "Houston, TX"]
    ):
        return { 
            "type": "extreme_cold", 
            "region": region, 
            "details": f"Temperatures dropping to {min_temp}°F, alerts: {alerts}" 
        } 
    # Impossible temperatures
    if (min_temp is not None and min_temp < -80) or (max_temp is not None and max_temp > 150):
        raise ValueError("Unphysical temperature detected.")


    # Nor'easter 
    if (
        region in ["Boston, MA", "New York City, NY"] 
        and precip >= 4 
        and max_temp is not None
        and max_temp < 35
    ):
       return { 
           "type": "noreaster", 
           "region": region, 
           "details": f"Heavy snow periods: {precip}, temps: {min_temp}–{max_temp}°F" 
       } 

    # Default story
    return {
        "type": "general",
        "region": region,
        "details": f"Clear skies and {metrics['max_temp']}°F"
        
def get_nasa_image(region): 
    nasa_key = os.environ["NASA_API_KEY"] 
    print("Fetching NASA APOD image...") 
    url = f"https://api.nasa.gov/planetary/apod?api_key={nasa_key}" 
    data = requests.get(url, headers=HEADERS).json() 
    print("NASA image fetched.") 
    east_regions = ["New York City, NY", "Boston, MA", "Miami, FL"]
    if region in east_regions: 
        return "https://cdn.star.nesdis.noaa.gov/GOES16/ABI/CONUS/GEOCOLOR/latest.jpg"    
    return "https://cdn.star.nesdis.noaa.gov/GOES18/ABI/CONUS/GEOCOLOR/latest.jpg"
    
def generate_story_text(story, metrics, alert_info): 
    llm_key = os.environ["LLM_API_KEY"] 
    
    prompt = f""" 
You are a professional meteorologist writing a concise national weather briefing.

Write:
- A single headline (no labels, no prefixes)
- One short briefing of NO MORE 12 sentences and AT LEAST 9 sentences
- Organize 9 to 12 sentences into at least 2 paragraphs and of no more than 3 paragraphs.

Example:
- (headline) Winter weather in Full Effect for the East Coast this Weekened
(Paragraph 1) Overview. While New York gets ready for plummeting temperatures, other parts of the United States are going to feel above normal temperatures.
That's not all for New York either as the Big Apple gets ready to experience a 0.10 inch or a dusting of snow into the weekend.
This is just the tail of a system that has been largely off to our east over the water. 

(Paragraph 2) After New York receives its light snowfall, the remainder of the forecast trends dry and getting warmer after the weekend.
Snow chances return for the east coast late next week while the west enjoys some sunny days and those warmer temperatures. 
Be prepared for any travel disruption with the winter weather alert in the Big City as rideshare availability may be down or flights delayed.

(Paragraph 3) An area of high pressure dominates the midwest into next week. No snow to speak of. The California coast of the United States 
will have seasonable weather with average temperatures and plenty of sunshine ahead. Aside from a bitter cold snap and light snow, winter weather
should trend mild with the most subtle hint of spring in the air as we proceed through February. Summary.

Rules:
- Do NOT create sections, subheadings, or lists
- Do NOT include labels like "National Weather Story" or "Forecast Timing"
- Do NOT repeat the same information
- Do NOT invent numbers
- Use ONLY the data provided
- Keep the tone factual, calm, and concise
- Reference multiple regions in weather story

DATA:
Region: {story['region']}
Tonight Low: {metrics['tonight_low']}
Tomorrow High: {metrics['tomorrow_high']}
Coldest Temp: {metrics['coldest_temp']}
Coldest Time: {metrics['coldest_time']}
Snow Periods: {metrics['snow_periods']}
Min Wind Chill: {metrics['min_wind_chill']}
Alerts: {alert_info['alerts']}
Severity: {alert_info['severity']}
"""
    response = requests.post( 
        "https://api.groq.com/openai/v1/chat/completions", 
        headers={"Authorization": f"Bearer {llm_key}"}, 
        json={ 
            "model": "llama-3.1-8b-instant", 
            "messages": [{"role": "user", "content": prompt}], 
            "max_tokens": 600 
        } 
    ).json() 
    
    print("LLM response:", response) 
    
    if "choices" not in response: 
        raise ValueError(f"LLM API failed: {response}") 
        
    content = response["choices"][0]["message"]["content"] 
    headline, body = content.split("\n", 1) 
    return headline.strip(), body.strip() 
    
def main(): 
    stories = [] 
    
    for region, info in REGIONS.items(): 
        lat, lon = info["coords"]
        forecast = get_forecast(lat, lon) 
        alerts = get_alerts(info["alert_area"]) 
        metrics = extract_weather_metrics(forecast) 
        alert_info = extract_alert_severity(alerts) 
        story = detect_story(region, metrics, alert_info) 
        all_region_data.append({
            "region": region,
            "metrics": metrics,
            "alerts": alert_info["alerts"]
        })
        
        if story: 
            story["metrics"] = metrics
            stories.append(story) 
            
    if not stories: 
        data = { 
            "has_story": False, 
            "generated_at": datetime.now(timezone.utc).isoformat(), 
            "headline": "No major national weather story detected", 
            "body": "Conditions are relatively quiet across major U.S. regions.", 
            "image_url": None, 
        } 
    
    else: 
        story = stories[0] 
        headline, body = generate_story_text(story, story["metrics"], alert_info) 
        image_url = get_nasa_image(story["region"]) 
        
        data = { 
            "has_story": True, 
            "generated_at": datetime.now(timezone.utc).isoformat(), 
            "headline": headline, 
            "body": body, 
            "image_url": image_url, } 
        
    os.makedirs("data", exist_ok=True) 
    with open("data/latest_weather.json", "w") as f: 
        json.dump(data, f, indent=2) 
        
if __name__ == "__main__": main()
