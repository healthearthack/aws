// Mood Marbles interactive logic
// Prototype: one marble per browser per day using localStorage.
// Future: replace local-only storage with a backend API for global, shared jars.

(function () {
  const STORAGE_KEY_COUNTS = 'moodMarblesCounts';
  const STORAGE_KEY_LAST_RESET = 'moodMarblesLastReset';
  const STORAGE_KEY_HAS_VOTED = 'moodMarblesHasVoted';

  const jarMarblesEl = document.getElementById('jarMarbles');
  const jarTallyEl = document.getElementById('jarTally');
  const jarStatusMessageEl = document.getElementById('jarStatusMessage');
  const jarDropZoneEl = document.getElementById('jarDropZone');
  const yearEl = document.getElementById('mmYear');

  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  let counts = { green: 0, red: 0 };

  function loadState() {
    const now = Date.now();
    const lastReset = parseInt(localStorage.getItem(STORAGE_KEY_LAST_RESET) || '0', 10);

    // Reset every 24 hours
    const twentyFourHours = 24 * 60 * 60 * 1000;
    if (!lastReset || now - lastReset > twentyFourHours) {
      counts = { green: 0, red: 0 };
      localStorage.setItem(STORAGE_KEY_COUNTS, JSON.stringify(counts));
      localStorage.setItem(STORAGE_KEY_LAST_RESET, String(now));
      localStorage.removeItem(STORAGE_KEY_HAS_VOTED);
    } else {
      const storedCounts = localStorage.getItem(STORAGE_KEY_COUNTS);
      if (storedCounts) {
        try {
          counts = JSON.parse(storedCounts);
        } catch {
          counts = { green: 0, red: 0 };
        }
      }
    }
  }

  function saveState() {
    localStorage.setItem(STORAGE_KEY_COUNTS, JSON.stringify(counts));
  }

  function hasVotedToday() {
    return localStorage.getItem(STORAGE_KEY_HAS_VOTED) === 'true';
  }

  function markVoted() {
    localStorage.setItem(STORAGE_KEY_HAS_VOTED, 'true');
  }

  function updateUI() {
    // Update tally text
    const total = counts.green + counts.red;
    jarTallyEl.textContent = `Green: ${counts.green} | Red: ${counts.red} | Total: ${total}`;

    // Render marbles in jar
    jarMarblesEl.innerHTML = '';
    const maxMarbles = Math.min(total, 60); // avoid overfilling visually
    const greensToShow = Math.min(counts.green, maxMarbles);
    const redsToShow = Math.min(counts.red, maxMarbles - greensToShow);

    for (let i = 0; i < greensToShow; i++) {
      const m = document.createElement('div');
      m.className = 'jar-marble green';
      jarMarblesEl.appendChild(m);
    }
    for (let i = 0; i < redsToShow; i++) {
      const m = document.createElement('div');
      m.className = 'jar-marble red';
      jarMarblesEl.appendChild(m);
    }
  }

  function showMessage(msg) {
    jarStatusMessageEl.textContent = msg;
  }

  function dropMarble(color) {
    if (hasVotedToday()) {
      showMessage('You already put a marble in for today! Come back tomorrow.');
      return;
    }

    if (color !== 'green' && color !== 'red') return;

    counts[color] += 1;
    saveState();
    markVoted();
    updateUI();
    showMessage(`Thanks for sharing your mood today (${color}).`);
  }

  // Drag & drop support
  function setupDragAndDrop() {
    const marbles = document.querySelectorAll('.marble');

    marbles.forEach(marble => {
      marble.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', marble.dataset.color);
      });

      // Keyboard / tap fallback: click to drop
      marble.addEventListener('click', () => {
        dropMarble(marble.dataset.color);
      });

      marble.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          dropMarble(marble.dataset.color);
        }
      });
    });

    jarDropZoneEl.addEventListener('dragover', (e) => {
      e.preventDefault();
    });

    jarDropZoneEl.addEventListener('drop', (e) => {
      e.preventDefault();
      const color = e.dataTransfer.getData('text/plain');
      dropMarble(color);
    });
  }

  // Initialize
  loadState();
  updateUI();
  setupDragAndDrop();
})();
