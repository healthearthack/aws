// Expand / collapse notes on hover and tap

document.addEventListener("DOMContentLoaded", () => {
  const notes = document.querySelectorAll("[data-note]");

  notes.forEach((note) => {
    // Hover for desktop
    note.addEventListener("mouseenter", () => {
      note.classList.add("expanded");
    });
    note.addEventListener("mouseleave", () => {
      note.classList.remove("expanded");
    });

    // Tap / click for mobile
    note.addEventListener("click", () => {
      // On small screens, toggle instead of just hover
      if (window.matchMedia("(max-width: 840px)").matches) {
        note.classList.toggle("expanded");
      }
    });
  });

  // Subtle parallax on hero parchment
  const hero = document.querySelector(".hero-parchment");
  if (hero) {
    hero.addEventListener("mousemove", (e) => {
      const rect = hero.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      hero.style.transform = `translateY(-1px) translateX(${x * 4}px)`;
    });

    hero.addEventListener("mouseleave", () => {
      hero.style.transform = "";
    });
  }
});
