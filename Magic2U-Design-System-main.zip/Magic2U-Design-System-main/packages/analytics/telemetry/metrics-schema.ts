export interface RenderMetric {
  component: string;
  renderTime: number;
  timestamp: number;
}

