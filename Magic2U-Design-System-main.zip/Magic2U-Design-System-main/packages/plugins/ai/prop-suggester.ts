export function suggestProps(componentName: string) {
  return [`${componentName.toLowerCase()}Id`, 'variant', 'size'];
}

