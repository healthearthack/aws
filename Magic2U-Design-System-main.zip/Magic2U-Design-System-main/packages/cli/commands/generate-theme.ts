import { createTheme } from '../../theme-engine/createTheme';

export function generateTheme(config: any) {
  return createTheme(config);
}

