import tokens from "./tokens.json";

export const nameTheme = {
  name: "name",
  tokens
};

