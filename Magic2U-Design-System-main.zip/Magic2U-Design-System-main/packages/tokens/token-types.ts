export type Token = {
  name: string;
  value: string;
  category: string;
};

