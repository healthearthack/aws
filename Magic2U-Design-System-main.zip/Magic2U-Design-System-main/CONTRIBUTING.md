Thank you for your valued involvement with Magic2U-Design-System.

Light and versatile in application. 
